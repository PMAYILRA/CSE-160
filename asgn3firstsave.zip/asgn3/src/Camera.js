// camera.js
class Camera {
    constructor() {
      this.fov = 60;
      this.eye = new Vector3([100, 100, 100]);  // Start further back so we can see objects
      this.at = new Vector3([0, 0, -100]); // Looking at the origin
      this.up = new Vector3([0, 1, 0]);
      
      this.viewMatrix = new Matrix4();
      this.updateViewMatrix();
      
      this.projectionMatrix = new Matrix4();
      this.updateProjectionMatrix();
    }
    
    updateViewMatrix() {
      this.viewMatrix.setLookAt(
        this.eye.elements[0], this.eye.elements[1], this.eye.elements[2],
        this.at.elements[0], this.at.elements[1], this.at.elements[2],
        this.up.elements[0], this.up.elements[1], this.up.elements[2]
      );
    }
    
    updateProjectionMatrix() {
      const canvas = document.getElementById('webgl');
      this.projectionMatrix.setPerspective(
        this.fov,
        canvas.width / canvas.height,
        0.1,
        1000
      );
    }
    
    moveForward(speed = 0.1) {
      // Calculate forward vector
      let f = new Vector3([
        this.at.elements[0] - this.eye.elements[0],
        this.at.elements[1] - this.eye.elements[1],
        this.at.elements[2] - this.eye.elements[2]
      ]);
      f.normalize();
      
      // Move eye and at
      this.eye.elements[0] += f.elements[0] * speed;
      this.eye.elements[1] += f.elements[1] * speed;
      this.eye.elements[2] += f.elements[2] * speed;
      
      this.at.elements[0] += f.elements[0] * speed;
      this.at.elements[1] += f.elements[1] * speed;
      this.at.elements[2] += f.elements[2] * speed;
      
      this.updateViewMatrix();
    }
    
    moveBackwards(speed = 0.1) {
      // Calculate backward vector
      let b = new Vector3([
        this.eye.elements[0] - this.at.elements[0],
        this.eye.elements[1] - this.at.elements[1],
        this.eye.elements[2] - this.at.elements[2]
      ]);
      b.normalize();
      
      // Move eye and at
      this.eye.elements[0] += b.elements[0] * speed;
      this.eye.elements[1] += b.elements[1] * speed;
      this.eye.elements[2] += b.elements[2] * speed;
      
      this.at.elements[0] += b.elements[0] * speed;
      this.at.elements[1] += b.elements[1] * speed;
      this.at.elements[2] += b.elements[2] * speed;
      
      this.updateViewMatrix();
    }
    
    moveLeft(speed = 0.1) {
      // Calculate forward vector
      let f = new Vector3([
        this.at.elements[0] - this.eye.elements[0],
        this.at.elements[1] - this.eye.elements[1],
        this.at.elements[2] - this.eye.elements[2]
      ]);
      f.normalize();
      
      // Calculate side vector (cross product up × forward)
      let s = new Vector3();
      s.elements[0] = this.up.elements[1] * f.elements[2] - this.up.elements[2] * f.elements[1];
      s.elements[1] = this.up.elements[2] * f.elements[0] - this.up.elements[0] * f.elements[2];
      s.elements[2] = this.up.elements[0] * f.elements[1] - this.up.elements[1] * f.elements[0];
      s.normalize();
      
      // Move eye and at
      this.eye.elements[0] += s.elements[0] * speed;
      this.eye.elements[1] += s.elements[1] * speed;
      this.eye.elements[2] += s.elements[2] * speed;
      
      this.at.elements[0] += s.elements[0] * speed;
      this.at.elements[1] += s.elements[1] * speed;
      this.at.elements[2] += s.elements[2] * speed;
      
      this.updateViewMatrix();
    }
    
    moveRight(speed = 0.1) {
      // Calculate forward vector
      let f = new Vector3([
        this.at.elements[0] - this.eye.elements[0],
        this.at.elements[1] - this.eye.elements[1],
        this.at.elements[2] - this.eye.elements[2]
      ]);
      f.normalize();
      
      // Calculate side vector (cross product forward × up)
      let s = new Vector3();
      s.elements[0] = f.elements[1] * this.up.elements[2] - f.elements[2] * this.up.elements[1];
      s.elements[1] = f.elements[2] * this.up.elements[0] - f.elements[0] * this.up.elements[2];
      s.elements[2] = f.elements[0] * this.up.elements[1] - f.elements[1] * this.up.elements[0];
      s.normalize();
      
      // Move eye and at
      this.eye.elements[0] += s.elements[0] * speed;
      this.eye.elements[1] += s.elements[1] * speed;
      this.eye.elements[2] += s.elements[2] * speed;
      
      this.at.elements[0] += s.elements[0] * speed;
      this.at.elements[1] += s.elements[1] * speed;
      this.at.elements[2] += s.elements[2] * speed;
      
      this.updateViewMatrix();
    }
    
    panLeft(alpha = 1) {
      // Calculate forward vector
      let f = new Vector3([
        this.at.elements[0] - this.eye.elements[0],
        this.at.elements[1] - this.eye.elements[1],
        this.at.elements[2] - this.eye.elements[2]
      ]);
      
      // Create rotation matrix
      let rotationMatrix = new Matrix4();
      rotationMatrix.setRotate(alpha, this.up.elements[0], this.up.elements[1], this.up.elements[2]);
      
      // Rotate forward vector
      let f_prime = rotationMatrix.multiplyVector3(f);
      
      // Update at point
      this.at.elements[0] = this.eye.elements[0] + f_prime.elements[0];
      this.at.elements[1] = this.eye.elements[1] + f_prime.elements[1];
      this.at.elements[2] = this.eye.elements[2] + f_prime.elements[2];
      
      this.updateViewMatrix();
    }
    
    panRight(alpha = 1) {
      this.panLeft(-alpha);
    }
  }