class Cube {
  constructor() {
    this.type = 'cube';
    this.color = [1.0, 1.0, 1.0, 1.0];
    this.matrix = new Matrix4();
    this.texture = null;
    this.vertexBuffer = null;
    this.texCoordBuffer = null;
  }

  render() {
    // Set the model matrix
    gl.uniformMatrix4fv(u_ModelMatrix, false, this.matrix.elements);

    // If texture exists, use it
    if (this.texture) {
      gl.activeTexture(gl.TEXTURE0);
      gl.bindTexture(gl.TEXTURE_2D, this.texture);
      gl.uniform1i(u_Sampler, 0);
      gl.uniform1f(u_TexColorWeight, 1.0);
    } else {
      gl.uniform1f(u_TexColorWeight, 0.0);
      gl.uniform4fv(u_BaseColor, this.color);
    }

    // Set up position buffer
    if (this.vertexBuffer === null) {
      this.vertexBuffer = gl.createBuffer();
      const vertices = new Float32Array([
        // Front face
        0, 0, 0, 1, 0, 0, 1, 1, 0,
        0, 0, 0, 1, 1, 0, 0, 1, 0,
        // Back face
        0, 0, 1, 1, 0, 1, 1, 1, 1,
        0, 0, 1, 1, 1, 1, 0, 1, 1,
        // Top face
        0, 1, 0, 1, 1, 0, 1, 1, 1,
        0, 1, 0, 1, 1, 1, 0, 1, 1,
        // Bottom face
        0, 0, 0, 1, 0, 0, 1, 0, 1,
        0, 0, 0, 1, 0, 1, 0, 0, 1,
        // Right face
        1, 0, 0, 1, 0, 1, 1, 1, 1,
        1, 0, 0, 1, 1, 1, 1, 1, 0,
        // Left face
        0, 0, 0, 0, 0, 1, 0, 1, 1,
        0, 0, 0, 0, 1, 1, 0, 1, 0
      ]);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, vertices, gl.STATIC_DRAW);
    }
    gl.bindBuffer(gl.ARRAY_BUFFER, this.vertexBuffer);
    gl.vertexAttribPointer(a_Position, 3, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_Position);

    // Set up texture coordinates
    if (this.texCoordBuffer === null) {
      this.texCoordBuffer = gl.createBuffer();
      const texCoords = new Float32Array([
        // Front face
        0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1,
        // Back face
        0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1,
        // Top face
        0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1,
        // Bottom face
        0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1,
        // Right face
        0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1,
        // Left face
        0, 0, 1, 0, 1, 1, 0, 0, 1, 1, 0, 1
      ]);
      gl.bindBuffer(gl.ARRAY_BUFFER, this.texCoordBuffer);
      gl.bufferData(gl.ARRAY_BUFFER, texCoords, gl.STATIC_DRAW);
    }
    gl.bindBuffer(gl.ARRAY_BUFFER, this.texCoordBuffer);
    gl.vertexAttribPointer(a_TexCoord, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(a_TexCoord);

    // Draw the cube
    gl.drawArrays(gl.TRIANGLES, 0, 36);
  }
}
