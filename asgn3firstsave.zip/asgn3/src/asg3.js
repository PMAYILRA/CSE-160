//Pranav Mayilraj
//pmayilra@ucsc.edu

//Notes to Grader:
//Read README

const POINT = 0;
const TRIANGLE = 1;
const CIRCLE = 2;
var VSHADER_SOURCE = `
  attribute vec4 a_Position;
  attribute vec2 a_TexCoord;
  uniform mat4 u_ModelMatrix;
  uniform mat4 u_ViewMatrix;
  uniform mat4 u_ProjectionMatrix;
  uniform mat4 u_GlobalRotateMatrix;
  varying vec2 v_TexCoord;
  void main() {
    gl_Position = u_ProjectionMatrix * u_ViewMatrix * u_GlobalRotateMatrix * u_ModelMatrix * a_Position;
    v_TexCoord = a_TexCoord;
  }`;


var FSHADER_SOURCE = `
  #ifdef GL_ES
  precision mediump float;
  #endif
  uniform sampler2D u_Sampler;
  uniform vec4 u_BaseColor;
  uniform float u_TexColorWeight;
  varying vec2 v_TexCoord;
  void main() {
    vec4 texColor = texture2D(u_Sampler, v_TexCoord);
    gl_FragColor = (1.0 - u_TexColorWeight) * u_BaseColor + u_TexColorWeight * texColor;
  }`;

var canvas;
var gl;
var a_Position;
var u_FragColor;
var u_Size;
var u_ModelMatrix;
var u_GlobalRotateMatrix;

var a_TexCoord; // NEW - Texture coordinate attribute
var u_Sampler;  // NEW - Texture sampler uniform
var texture;    // NEW - Texture object

var g_selectedColor = [1.0, 1.0, 1.0, 1.0];
var g_selectedSize = 5;
var g_Type = POINT;
var g_selectedSegments = 10;
var g_globalAngle = 0;

var g_shapesList = [];

var g_leftArmJointAngle = -235;
var g_rightArmJointAngle = 235;
var g_leftArmAngle = 0;
var g_rightArmAngle = -55;

var g_startTime = performance.now() / 1000.0;
var g_seconds = performance.now() / 1000.0 - g_startTime;

var g_leftArmAnimation = false;

var g_leftLegAngle = 0;
var g_rightLegAngle = 0;
var g_legAnimation = false;

var g_base, g_base2, g_head, g_leftEye, g_rightEye, g_nose;
var g_leftJoint, g_leftArm, g_rightJoint, g_rightArm;
var g_leftLeg, g_rightLeg;
var g_rightHand;

var groundPlane = null;

var g_isPokeAnimation = false;
var g_pokeStartTime = 0;
let g_isDragging = false;
let g_lastMouseX = 0;
let g_rotationSpeed = 0.3;
let g_rotationMatrix = new Matrix4();

let g_frameCount = 0;
let g_lastTime = performance.now();
let g_fps = 0;
let g_fpsElement;

var u_BaseColor;
var u_TexColorWeight;

var g_isPokeAnimation = false;

var u_ViewMatrix;
var u_ProjectionMatrix;
var g_viewMatrix;
var g_projectionMatrix;
var camera;



function setupWebGL() {
  canvas = document.getElementById('webgl');

  gl = getWebGLContext(canvas);
  if (!gl) {
    console.log('Failed to get the rendering context for WebGL');
    return;
  }
}

function connectVariablesToGLSL() {
  if (!initShaders(gl, VSHADER_SOURCE, FSHADER_SOURCE)) {
      console.log('Failed to intialize shaders.');
      return;
  }

  a_Position = gl.getAttribLocation(gl.program, 'a_Position');
  if (a_Position < 0) {
      console.log('Failed to get the storage location of a_Position');
      return;
  }
  
  a_TexCoord = gl.getAttribLocation(gl.program, 'a_TexCoord');  // Get texture coord location
  if (a_TexCoord < 0) {
      console.log('Failed to get the storage location of a_TexCoord');
      return;
  }

  //u_FragColor = gl.getUniformLocation(gl.program, 'u_FragColor');
  // if (!u_FragColor) {
  //     console.log('Failed to get the storage location of u_FragColor');
  //     return;
  // }

  //u_Size = gl.getUniformLocation(gl.program, 'u_Size');
  // if (!u_FragColor) {
  //     console.log('Failed to get the storage location of u_Size');
  //     return;
  // }

  u_ModelMatrix = gl.getUniformLocation(gl.program, 'u_ModelMatrix');
  if (!u_ModelMatrix) {
      console.log('Failed to get the storage location of u_ModelMatrix');
      return;
  }

  u_GlobalRotateMatrix = gl.getUniformLocation(gl.program, 'u_GlobalRotateMatrix');
  if (!u_GlobalRotateMatrix) {
      console.log('Failed to get the storage location of u_GlobalRotateMatrix');
      return;
  }
  
  u_Sampler = gl.getUniformLocation(gl.program, 'u_Sampler'); // Get sampler location
  if (!u_Sampler) {
      console.log('Failed to get the storage location of u_Sampler');
      return;
  }

  u_BaseColor = gl.getUniformLocation(gl.program, 'u_BaseColor');
  if (!u_BaseColor) {
      console.log('Failed to get the storage location of u_BaseColor');
      return;
  }

  u_TexColorWeight = gl.getUniformLocation(gl.program, 'u_TexColorWeight');
  if (!u_TexColorWeight) {
      console.log('Failed to get the storage location of u_TexColorWeight');
      return;
  }

  u_ViewMatrix = gl.getUniformLocation(gl.program, 'u_ViewMatrix');
  if (!u_ViewMatrix) {
    console.log('Failed to get the storage location of u_ViewMatrix');
    return;
  }

  u_ProjectionMatrix = gl.getUniformLocation(gl.program, 'u_ProjectionMatrix');
  if (!u_ProjectionMatrix) {
    console.log('Failed to get the storage location of u_ProjectionMatrix');
    return;
  }
}

function addActionsForHtmlUI() {
  document.getElementById('leftArmAnimateButton').onclick = function () {
    g_leftArmAnimation = !g_leftArmAnimation;
  };
  document.getElementById('legAnimateButton').onclick = function () {
    g_legAnimation = !g_legAnimation;
  };
  document.getElementById('leftArmJointSlide').addEventListener('mousemove', function () {
    g_leftArmJointAngle = this.value;
    renderAllShapes();
  });
  document.getElementById('rightArmJointSlide').addEventListener('mousemove', function () {
    g_rightArmJointAngle = this.value;
    renderAllShapes();
  });
  document.getElementById('leftArmSlide').addEventListener('mousemove', function () {
    g_leftArmAngle = this.value;
    renderAllShapes();
  });

  document.getElementById('rightArmSlide').addEventListener('mousemove', function () {
    g_rightArmAngle = this.value;
    renderAllShapes();
  });
  canvas.onmousedown = function (event) {
    g_isDragging = true;
    g_lastMouseX = event.clientX;
  
    if (event.shiftKey) {
      g_isPokeAnimation = true;
      g_leftArmAnimation = true;
      g_legAnimation = true;
    }
  };
  
  canvas.onmouseup = function () {
    g_isDragging = false;
  
    g_isPokeAnimation = false;
    g_leftArmAnimation = false;
    g_legAnimation = false;
  };


  canvas.onmousemove = function (event) {
    if (g_isDragging) {
      const deltaX = event.clientX - g_lastMouseX;
      g_rotationMatrix.rotate(deltaX * g_rotationSpeed, 0, 1, 0);
      g_lastMouseX = event.clientX;
      renderAllShapes();
    }
  };

  canvas.addEventListener('click', function(event) {
    if (event.shiftKey) {
        g_leftArmAnimation = true;
        g_legAnimation = true;
        g_isPokeAnimation = true;
        g_pokeStartTime = performance.now() / 1000.0;
    }
    });

    document.onkeydown = function(ev) {
      const key = ev.key.toLowerCase(); // case-insensitive
      const speed = ev.shiftKey ? 0.2 : 0.1; // faster when shift is held
  
      switch(key) {
        case 'w':
          camera.moveForward(speed);
          break;
        case 's':
          camera.moveBackwards(speed);
          break;
        case 'a':
          camera.moveLeft(speed);
          break;
        case 'd':
          camera.moveRight(speed);
          break;
        case 'q':
          camera.panLeft();
          break;
        case 'e':
          camera.panRight();
          break;
        case 'arrowup':
          // Optional: add vertical movement
          camera.eye.elements[1] += speed;
          camera.at.elements[1] += speed;
          camera.updateViewMatrix();
          break;
        case 'arrowdown':
          // Optional: add vertical movement
          camera.eye.elements[1] -= speed;
          camera.at.elements[1] -= speed;
          camera.updateViewMatrix();
          break;
        default:
          return; // exit if no relevant key was pressed
      }
      renderAllShapes();
    };

  g_fpsElement = document.createElement('div');
  g_fpsElement.style.position = 'absolute';
  g_fpsElement.style.top = '10px';
  g_fpsElement.style.left = '10px';
  g_fpsElement.style.color = 'white';
  g_fpsElement.style.zIndex = '10';
  document.body.appendChild(g_fpsElement);
}

function updateSelectedColor() {
  const r = parseFloat(document.getElementById('redSlider').value);
  const g = parseFloat(document.getElementById('greenSlider').value);
  const b = parseFloat(document.getElementById('blueSlider').value);

  g_selectedColor = [r, g, b, 1.0];
}

function initTextures() {
  // Create texture object
  var stoneTexture = gl.createTexture();
  if (!stoneTexture) {
    console.log('Failed to create texture object');
    return false;
  }

  // Load stone texture
  var stoneImage = new Image();
  stoneImage.onload = function() {
    loadTexture(stoneImage, stoneTexture);
    renderAllShapes();
  };
  stoneImage.onerror = function() {
    console.log('Failed to load stone texture');
  };
  stoneImage.src = 'stone.jpg';

  // Store texture globally
  window.textures = {
    stone: stoneTexture
  };
  
  return true;
}

function loadTexture(image, texture) {
  gl.bindTexture(gl.TEXTURE_2D, texture);
  gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGB, gl.RGB, gl.UNSIGNED_BYTE, image);
  
  // Set texture parameters
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.REPEAT);
  gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.REPEAT);
  
  // Only generate mipmaps if needed (for better quality at small scales)
  // gl.generateMipmap(gl.TEXTURE_2D);
}

function main() {
  setupWebGL();
  connectVariablesToGLSL();
  gl.enable(gl.DEPTH_TEST);
  addActionsForHtmlUI();
  
  // Initialize camera
  camera = new Camera();
  
  // Initialize texture before first render
  initTextures();
  
  // Set clear color
  gl.clearColor(0.0, 0.0, 0.0, 1.0);
  
  // Initial render (don't wait for first tick)
  renderAllShapes();
  
  // Start animation loop
  requestAnimationFrame(tick);
}

function tick() {
  g_seconds = performance.now() / 1000.0 - g_startTime;

  updateAnimationAngles();
  renderAllShapes();
  updateFPS();

  requestAnimationFrame(tick);
}

function updateAnimationAngles() {
    if (g_leftArmAnimation) {
      if (g_isPokeAnimation) {
        let pokeElapsed = g_seconds - g_pokeStartTime;
        g_leftArmAngle = 30 * Math.sin(6 * pokeElapsed);
      } else {
        g_leftArmAngle = 30 * Math.sin(g_seconds);
      }
    }
  
    if (g_legAnimation) {
      if (g_isPokeAnimation) {
        let pokeElapsed = g_seconds - g_pokeStartTime;
        g_leftLegAngle = 60 * Math.sin(6 * pokeElapsed);
        g_rightLegAngle = -60 * Math.sin(6 * pokeElapsed);
      } else {
        g_leftLegAngle = 30 * Math.sin(g_seconds);
        g_rightLegAngle = -30 * Math.sin(g_seconds);
      }
    }
  }

function convertCoordinatesEventToGL(ev) {
  var x = ev.clientX;
  var y = ev.clientY;
  var rect = ev.target.getBoundingClientRect();

  x = ((x - rect.left) - canvas.width / 2) / (canvas.width / 2);
  y = (canvas.height / 2 - (y - rect.top)) / (canvas.height / 2);

  return ([x, y]);
}

function renderAllShapes() {
  // Clear both color and depth buffers
  gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

  gl.uniformMatrix4fv(u_ViewMatrix, false, camera.viewMatrix.elements);
  gl.uniformMatrix4fv(u_ProjectionMatrix, false, camera.projectionMatrix.elements);

  // Set global rotation
  var globalRotMat = new Matrix4();
  globalRotMat.multiply(g_rotationMatrix);
  gl.uniformMatrix4fv(u_GlobalRotateMatrix, false, globalRotMat.elements);

  // Rest of your rendering code...
  // Draw skybox (pure blue)
  gl.uniform4f(u_BaseColor, 0.2, 0.6, 1.0, 1.0); // Blue color
  gl.uniform1f(u_TexColorWeight, 0.0); // No texture
  drawSkybox();

  // Draw textured walls
  gl.uniform4f(u_BaseColor, 1.0, 1.0, 1.0, 1.0); // White base
  gl.uniform1f(u_TexColorWeight, 1.0); // Full texture
  drawTexturedWalls();

  drawGround();

  drawWalls();
}

function drawSkybox() {
  var skybox = new Cube();
  skybox.color = [0.2, 0.6, 1.0, 1.0]; // Blue
  skybox.matrix.scale(100, 100, 100); // Very large
  skybox.matrix.translate(-0.5, -0.5, -0.5); // Center
  skybox.render();
}

function drawGround() {
  if (!groundPlane) {
    groundPlane = new Cube();
    groundPlane.color = [0.0, 0.4, 0.0, 1.0];  // Dark Green
    
    // Scale first (100 units in each direction)
    groundPlane.matrix.scale(100, 0.1, 100);  
    
    // Then translate so center is at (0, -2, 0)
    groundPlane.matrix.translate(-0.5, 0, -0.5);  // Center the cube
    groundPlane.matrix.translate(0, -2, 0);  // Move down to y=-2
  }
  
  gl.uniform4f(u_BaseColor, groundPlane.color[0], groundPlane.color[1], groundPlane.color[2], groundPlane.color[3]);
  gl.uniform1f(u_TexColorWeight, 0.0); // No texture
  groundPlane.render();
}
function drawWalls() {
  if (!window.textures || !window.textures.stone) {
    console.log("Texture not loaded yet");
    return;
  }

  // Wall layout and heights
  const map = [
    [1, 0, 0, 1],
    [1, 1, 0, 1],
    [1, 0, 0, 1],
    [1, 1, 1, 1]
  ];

  const wallHeightMap = [
    [1, 0, 0, 1],
    [1, 1.5, 0, 1],
    [1, 0, 0, 1],
    [1, 1, 1, 1]
  ];

  const wallSize = 0.5;
  const spacing = 1.0;

  // Set texture parameters (do this once before rendering all walls)
  gl.uniform4f(u_BaseColor, 1.0, 1.0, 1.0, 1.0); // White base
  gl.uniform1f(u_TexColorWeight, 1.0); // Full texture

  // Create one cube instance and reuse it (more efficient)
  const wallCube = new Cube();
  wallCube.texture = window.textures.stone;

  for (let x = 0; x < map.length; x++) {
    for (let z = 0; z < map[x].length; z++) {
      if (map[x][z] === 1) {
        const height = wallHeightMap[x][z];
        
        // Reset matrix for each wall segment
        wallCube.matrix = new Matrix4();
        
        // Position and scale
        wallCube.matrix.translate(
          x * spacing - 2.0, 
          height/2 - 1,  // Center vertically
          z * spacing - 2.0
        );
        wallCube.matrix.scale(wallSize, height, wallSize);
        
        wallCube.render();
      }
    }
  }
}

function drawTexturedWalls() {
  // Create a simple wall
  var wall = new Cube();
  wall.color = [1.0, 1.0, 1.0, 1.0];
  wall.matrix.translate(0, 0, -2); // Place in front of camera
  wall.matrix.scale(4, 2, 0.1); // Wide and tall, but thin
  wall.render();
}

function drawTexturedQuad() {
  // Define vertices and texture coordinates for a full-screen quad
  const verticesTexCoords = new Float32Array([
    // Vertex coordinates (x,y), texture coordinates (s,t)
    -0.5,  0.5,   0.0, 1.0,  // top-left
    -0.5, -0.5,   0.0, 0.0,  // bottom-left
     0.5,  0.5,   1.0, 1.0,  // top-right
     0.5, -0.5,   1.0, 0.0   // bottom-right
  ]);

  // Create buffer if it doesn't exist
  if (!window.textureQuadBuffer) {
    window.textureQuadBuffer = gl.createBuffer();
    if (!window.textureQuadBuffer) {
      console.log('Failed to create the buffer object');
      return;
    }
  }

  // Bind and fill buffer
  gl.bindBuffer(gl.ARRAY_BUFFER, window.textureQuadBuffer);
  gl.bufferData(gl.ARRAY_BUFFER, verticesTexCoords, gl.STATIC_DRAW);

  const FSIZE = verticesTexCoords.BYTES_PER_ELEMENT;

  // Set up position attribute
  gl.vertexAttribPointer(a_Position, 2, gl.FLOAT, false, FSIZE * 4, 0);
  gl.enableVertexAttribArray(a_Position);

  // Set up texture coordinate attribute
  gl.vertexAttribPointer(a_TexCoord, 2, gl.FLOAT, false, FSIZE * 4, FSIZE * 2);
  gl.enableVertexAttribArray(a_TexCoord);

  // Temporarily set identity matrix for the quad
  var identityMat = new Matrix4();
  gl.uniformMatrix4fv(u_ModelMatrix, false, identityMat.elements);

  // Draw the textured quad
  gl.drawArrays(gl.TRIANGLE_STRIP, 0, 4);
}

function updateFPS() {
  g_frameCount++;
  const currentTime = performance.now();
  const deltaTime = currentTime - g_lastTime;

  if (deltaTime >= 250) {
    g_fps = Math.round((g_frameCount * 1000) / deltaTime);
    g_fpsElement.textContent = 'FPS: ' + g_fps;
    g_lastTime = currentTime;
    g_frameCount = 0;
  }
}