README

Basic scene is working - To have a scene with at least 3 different primary shapes (e.g. cube, sphere, cylinder, etc), at least one of these shapes is animated, a directional light source and a camera with perspective projection. - check
At least one primary shape in your scene is textured. - check (floor)
To have a custom textured 3D model (glb, gltf or obj file with .mtl loaded). - check (vase)
To be able to move the camera with controls. - check
To have at least 3 different light sources into your scene. - point, ambient, directional (check)
To have a skybox in your scene. - doesn't really make sense with the scene but I couldnt find a better one trust me (check)
To have at least 20 primary shapes in your scene. - check (chair includes legs, seat, and back)
Extra Feature - falling forks game (avoid the forks, 3 lives if you lose all lives you lose)
